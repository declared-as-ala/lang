package com.linguabridge.backend.controller;

import com.linguabridge.backend.model.QuizQuestion;
import com.linguabridge.backend.service.QuizService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/quiz")
@RequiredArgsConstructor
public class QuizController {

    private final QuizService quizService;

    @GetMapping("/{type}")
    public ResponseEntity<List<QuizQuestion>> getQuestions(
            @PathVariable String type,
            @RequestParam String level
    ) {
        return ResponseEntity.ok(quizService.getQuestionsByTypeAndLevel(type, level));
    }
}
