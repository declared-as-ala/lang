package com.linguabridge.backend.service;

import com.linguabridge.backend.client.TogetherAIClient;
import com.linguabridge.backend.dto.TranslateRequest;
import com.linguabridge.backend.dto.TranslateResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Converts ENG → DE and fetches an illustration.
 */
@Service
@RequiredArgsConstructor
public class TranslationService {

    private final TogetherAIClient togetherAIClient;

    // ► Replace with a real dictionary later
    private static final Map<String,String> WORDS = Map.of(
            "dog",   "der Hund",
            "apple", "der Apfel"
    );

    public TranslateResponse translate(TranslateRequest req) {

        String english = req.getText().trim().toLowerCase();
        String german  = WORDS.getOrDefault(english, "—");

        // ask Together AI for an image
        String img;
        try {
            img = togetherAIClient.generateImage(english);
        } catch (Exception e) {
            img = "https://placehold.co/600x400?text=Image+Unavailable";
        }

        return TranslateResponse.builder()
                .english(english)
                .german(german)
                .pronunciation("—")              // stub
                .imageUrl(img)
                .exampleEnglish("I like to eat a " + english + ".")
                .exampleGerman("Ich esse gern einen " + german + ".")
                .tags(List.of("demo", "flashcard"))
                .build();
    }
}
