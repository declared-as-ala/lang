package com.linguabridge.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinguaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinguaBackendApplication.class, args);
	}

}
