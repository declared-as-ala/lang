package com.linguabridge.backend.dto;

import lombok.Data;

@Data
public class TranslateParagraphRequest {
    private String text;
}