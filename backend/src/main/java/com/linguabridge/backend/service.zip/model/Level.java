package com.linguabridge.backend.model;

public enum Level {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
} 