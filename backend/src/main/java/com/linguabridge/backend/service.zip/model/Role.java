package com.linguabridge.backend.model;

public enum Role {
    USER,
    ADMIN
} 